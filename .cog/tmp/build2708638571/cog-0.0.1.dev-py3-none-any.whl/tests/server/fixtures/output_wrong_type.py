from cog import BasePredictor


class Predictor(BasePredictor):
    def predict(self) -> int:
        return "foo"
